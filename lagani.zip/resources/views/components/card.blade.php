<div {{$attributes->merge(['class' => 'w-full bg-white text-stone-800 rounded px-4 py-6 gap-4 text-2xl flex items-center'])}}>
{{$slot}}
</div>