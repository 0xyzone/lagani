<div {{$attributes->merge(['class' => 'container px-6 mx-auto z-10 h-full'])}}>
 {{$slot}}
</div>