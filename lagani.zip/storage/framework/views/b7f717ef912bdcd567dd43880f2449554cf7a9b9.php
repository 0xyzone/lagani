<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => ['title' => $title]]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
    <div class="flex flex-col flex-1 w-full items-center">
        <form action="/transactions/withdrawl/<?php echo e($withdrawl->id); ?>/update" method="post" class="w-full lg:w-4/12 forms !gap-4">
            <div class="text-2xl font-bold text-center mb-4">Update Withdrawl #<?php echo e($withdrawl->id); ?></div>
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <select name="user_id" id="user_id" class="text-gray-200">
                <option value="" disabled
                    <?php if($withdrawl->user_id): ?> <?php else: ?>
                    selected <?php endif; ?> hidden>Please select a
                    user</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($user->id == 1): ?>
                        <?php continue; ?>
                    <?php endif; ?>
                    <option value="<?php echo e($user->id); ?>"
                        <?php if($withdrawl->user_id == $user->id): ?> selected
                    <?php else: ?> <?php endif; ?>><?php echo e($user->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="flex items-center gap-2">
                <label for="transaction_date" class="text-right">Transaction Date: </label>
                <input type="date" name="transaction_date" id="transaction_date" class="text-lg"
                    value="<?php echo e($withdrawl->transaction_date); ?>">
            </div>
            <?php $__errorArgs = ['transaction_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="flex items-center gap-2">
                <label for="cheque_no" class="text-right">Cheque Number</label>
                <input type="number" name="cheque_no" id="cheque_no" placeholder="Cheque No." value="<?php echo e($withdrawl->cheque_no); ?>">
            </div>
            <?php $__errorArgs = ['cheque_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="relative flex">
                <p class="absolute bottom-1.5 font-extrabold">रू</p>
                <input type="number" name="amount" id="amount" placeholder="Amount" autocomplete="off"
                    class="appearance-none ml-5" value="<?php echo e($withdrawl->amount); ?>">
            </div>
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <textarea name="comments" id="comments" rows="2" placeholder="Some comments here..."
                class="rounded-lg bg-gray-300/50 placeholder:text-gray-300 text-white"><?php echo e($withdrawl->comments); ?></textarea>
            <?php $__errorArgs = ['comments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div class="flex items-center gap-4">
                <input class="w-4 ring-0 border-none outline-none focus:ring-0 focus:border-0 focus:outline-none smooth"
                    type="checkbox" name="verified" id="verified" value="VERIFIED" checked>
                <label for="verified">I hereby declair that all the information above is correct and I declair it to be
                    verified.</label>
            </div>
            <?php $__errorArgs = ['verified'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-300 text-sm font-thin"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="submit" class="btn-primary w-max mx-auto">Update</button>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\lagani\resources\views/transactions/withdrawlEdit.blade.php ENDPATH**/ ?>