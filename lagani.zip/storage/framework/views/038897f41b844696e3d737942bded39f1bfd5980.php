<div class="bg-transparent border rounded-lg py-8 px-8 w-full flex justify-between items-center fadeInTop smooth">
    <h1 class="text-2xl font-bold"><?php echo e($title); ?></h1>
    <div class="flex gap-4">
        <?php echo e($slot); ?>

    </div>
</div><?php /**PATH D:\xampp\htdocs\lagani\resources\views/components/top-bar.blade.php ENDPATH**/ ?>