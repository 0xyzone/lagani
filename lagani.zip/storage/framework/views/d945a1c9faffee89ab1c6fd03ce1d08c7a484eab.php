<div <?php echo e($attributes->merge(['class' => 'container px-6 mx-auto z-10 h-full'])); ?>>
 <?php echo e($slot); ?>

</div><?php /**PATH D:\xampp\htdocs\lagani\resources\views/components/container.blade.php ENDPATH**/ ?>