<div <?php echo e($attributes->merge(['class' => 'w-full bg-white text-stone-800 rounded px-4 py-6 gap-4 text-2xl flex items-center'])); ?>>
<?php echo e($slot); ?>

</div><?php /**PATH D:\xampp\htdocs\lagani\resources\views/components/card.blade.php ENDPATH**/ ?>